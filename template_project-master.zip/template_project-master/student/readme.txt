Tähän hakemistoon kopioit projektipohjat templates hakemistosta tai luot uudet projektit.
