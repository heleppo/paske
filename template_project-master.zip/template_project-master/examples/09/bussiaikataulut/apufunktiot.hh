// Lähdekooditiedosto: apufunktiot.hh
#ifndef APUFUNKTIOT_HH
#define APUFUNKTIOT_HH

#include <string>

using namespace std;

bool string_intiksi(const string& syote, int& tulos);
bool lue_kokonaisluku(const string& kehote, int& tulos);

#endif
