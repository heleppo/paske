#include <iostream>
#include <memory>
#include "cards.hh"


Cards::Cards(): top_( nullptr ) {
}


void Cards::add(int id) {
    std::shared_ptr<Card_data> new_card 
            = std::make_shared<Card_data>(Card_data{id, top_});
    top_ = new_card;
}

void Cards::print(std::ostream& s) {
   std::shared_ptr<Card_data> to_be_printed = top_;
   int nr = 1;

   while( to_be_printed != 0 ) {
      s << nr << ": " << to_be_printed->data << std::endl;
      to_be_printed = to_be_printed->next;
      ++nr;
   }
}

// Älä kirjoita metodien remove ja reverse stubeja tähän itse, 
// vaan avaa tiedosto cards.hh ja klikkaa metodin esittelyä 
// hiiren oikeanpuoleisella näppäimellä ja valitse toiminto 
// Refactor > Add definition in cards.cpp
