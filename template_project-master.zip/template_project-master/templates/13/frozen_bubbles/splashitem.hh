#ifndef SPLASHITEM_H
#define SPLASHITEM_H

#include <QGraphicsPixmapItem>

class SplashItem : public QGraphicsPixmapItem
{
public:
    SplashItem();
};

#endif // SPLASHITEM_H
